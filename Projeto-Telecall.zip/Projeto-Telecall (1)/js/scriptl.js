function validarFormulario() {
  var login = document.getElementById("login");
  var senha = document.getElementById("senha");
  var errorContainer = document.getElementById("error-container");
  var errorMessages = [];

  if (login.value === "") {
    errorMessages.push("Por favor, preencha o campo de login.");
    login.classList.add("error-border");
  } else if (!/^[a-zA-Z]{6}$/.test(login.value)) {
    errorMessages.push("O campo de login deve conter exatamente 6 caracteres alfabéticos.");
    login.classList.add("error-border");
  } else {
    login.classList.remove("error-border");
    login.classList.add("success-border");
  }

  if (senha.value === "") {
    errorMessages.push("Por favor, preencha o campo de senha.");
    senha.classList.add("error-border");
  } else if (senha.value.length !== 8) {
    errorMessages.push("A senha deve ter exatamente 8 caracteres.");
    senha.classList.add("error-border");
  } else {
    senha.classList.remove("error-border");
    senha.classList.add("success-border");
  }

  if (errorMessages.length > 0) {
    errorContainer.innerHTML = "";
    for (var i = 0; i < errorMessages.length; i++) {
      var errorMessage = document.createElement("p");
      errorMessage.className = "error-message";
      errorMessage.textContent = errorMessages[i];
      errorContainer.appendChild(errorMessage);
    }
    return false;
  }

  return true;
}

let ul = document.querySelector('nav .ul');

function openMenu() {
  ul.classList.add('open');
}

function closeMenu() {
  ul.classList.remove('open');
}

const chk = document.getElementById('chk')

chk.addEventListener('change', () => {
  document.body.classList.toggle('dark')
})

