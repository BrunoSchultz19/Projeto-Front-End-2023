function marcarCampoValido(campo) {
  campo.classList.remove("campo-invalido");
  campo.classList.add("campo-valido");
}

function marcarCampoInvalido(campo) {
  campo.classList.remove("campo-valido");
  campo.classList.add("campo-invalido");
}

function validarFormulario() {
  var erros = document.getElementsByClassName("erro");
  for (var i = 0; i < erros.length; i++) {
    erros[i].innerHTML = "";
  }

  var validacao = true;

  var nome = document.getElementById("nome").value;
  if (nome.trim() === "") {
    document.getElementById("erro_nome").innerHTML = "Por favor, preencha o campo Nome.";
    marcarCampoInvalido(document.getElementById("nome"));
    validacao = false;
  } else if (nome.length < 15 || nome.length > 60 || !nome.match(/^[a-zA-Z\s]+$/)) {
    document.getElementById("erro_nome").innerHTML = "O campo Nome deve ter entre 15 e 60 caracteres alfabéticos.";
    marcarCampoInvalido(document.getElementById("nome"));
    validacao = false;
  } else {
    marcarCampoValido(document.getElementById("nome"));
  }

  var dataNascimento = document.getElementById("data_nascimento").value;
  if (dataNascimento.trim() === "") {
    document.getElementById("erro_data_nascimento").innerHTML = "Por favor, selecione a Data de Nascimento.";
    marcarCampoInvalido(document.getElementById("data_nascimento"));
    validacao = false;
  } else {
    marcarCampoValido(document.getElementById("data_nascimento"));
  }

  var sexo = document.getElementById("sexo").value;
  if (sexo.trim() === "") {
    document.getElementById("erro_sexo").innerHTML = "Por favor, selecione o Sexo.";
    marcarCampoInvalido(document.getElementById("sexo"));
    validacao = false;
  } else {
    marcarCampoValido(document.getElementById("sexo"));
  }

  var nomeMaterno = document.getElementById("nome_materno").value;
  if (nomeMaterno.trim() === "") {
    document.getElementById("erro_nome_materno").innerHTML = "Por favor, preencha o campo Nome Materno.";
    marcarCampoInvalido(document.getElementById("nome_materno"));
    validacao = false;
  } else {
    marcarCampoValido(document.getElementById("nome_materno"));
  }

  var cpf = document.getElementById("cpf").value;
  if (cpf.trim() === "") {
    document.getElementById("erro_cpf").innerHTML = "Por favor, preencha o campo CPF.";
    marcarCampoInvalido(document.getElementById("cpf"));
    validacao = false;
  } else if (!cpf.match(/^\d{3}\.\d{3}\.\d{3}-\d{2}$/)) {
    document.getElementById("erro_cpf").innerHTML = "O campo CPF deve estar no formato xxx.xxx.xxx-xx.";
    marcarCampoInvalido(document.getElementById("cpf"));
    validacao = false;
  } else {
    marcarCampoValido(document.getElementById("cpf"));
  }

  var telefoneCelular = document.getElementById("telefone_celular").value;
  if (telefoneCelular.trim() === "") {
    document.getElementById("erro_telefone_celular").innerHTML = "Por favor, preencha o campo Telefone Celular.";
    marcarCampoInvalido(document.getElementById("telefone_celular"));
    validacao = false;
  } else if (!telefoneCelular.match(/^\(?\+?\d{0,3}\)?\s?\d{2,3}-?\d{4,5}-?\d{4}$/)) {
    document.getElementById("erro_telefone_celular").innerHTML = "O campo Telefone Celular deve estar no formato adequado.";
    marcarCampoInvalido(document.getElementById("telefone_celular"));
    validacao = false;
  } else {
    marcarCampoValido(document.getElementById("telefone_celular"));
  }

  var telefoneFixo = document.getElementById("telefone_fixo").value;
  if (telefoneFixo.trim() !== "" && !telefoneFixo.match(/^\(?\+?\d{0,3}\)?\s?\d{2,3}-?\d{4,5}-?\d{4}$/)) {
    document.getElementById("erro_telefone_fixo").innerHTML = "O campo Telefone Fixo deve estar no formato adequado.";
    marcarCampoInvalido(document.getElementById("telefone_fixo"));
    validacao = false;
  } else {
    marcarCampoValido(document.getElementById("telefone_fixo"));
  }

  var endereco = document.getElementById("endereco").value;
  if (endereco.trim() === "") {
    document.getElementById("erro_endereco").innerHTML = "Por favor, preencha o campo Endereço Completo.";
    marcarCampoInvalido(document.getElementById("endereco"));
    validacao = false;
  } else {
    marcarCampoValido(document.getElementById("endereco"));
  }

  var login = document.getElementById("login").value;
  if (login.trim() === "") {
    document.getElementById("erro_login").innerHTML = "Por favor, preencha o campo Login.";
    marcarCampoInvalido(document.getElementById("login"));
    validacao = false;
  } else if (login.length !== 6 || !login.match(/^[a-zA-Z]+$/)) {
    document.getElementById("erro_login").innerHTML = "O campo Login deve ter exatamente 6 caracteres alfabéticos.";
    marcarCampoInvalido(document.getElementById("login"));
    validacao = false;
  } else {
    marcarCampoValido(document.getElementById("login"));
  }

  var senha = document.getElementById("senha").value;
  if (senha.trim() === "") {
    document.getElementById("erro_senha").innerHTML = "Por favor, preencha o campo Senha.";
    marcarCampoInvalido(document.getElementById("senha"));
    validacao = false;
  } else if (senha.length !== 8) {
    document.getElementById("erro_senha").innerHTML = "O campo Senha deve ter exatamente 8 caracteres.";
    marcarCampoInvalido(document.getElementById("senha"));
    validacao = false;
  } else {
    marcarCampoValido(document.getElementById("senha"));
  }

  var confirmarSenha = document.getElementById("confirmar_senha").value;
  if (senha !== confirmarSenha) {
    document.getElementById("erro_confirmar_senha").innerHTML = "A senha e a confirmação de senha não coincidem.";
    marcarCampoInvalido(document.getElementById("confirmar_senha"));
    validacao = false;
  } else {
    marcarCampoValido(document.getElementById("confirmar_senha"));
  }

  return validacao;
}

function formatarCPF() {
  var cpf = document.getElementById("cpf").value;
  cpf = cpf.replace(/\D/g, ""); 

  if (cpf.length > 11) {
    cpf = cpf.substring(0, 11);
  }

  if (cpf.length > 9) {
    cpf = cpf.substring(0, 9) + "-" + cpf.substring(9);
  }

  if (cpf.length > 6) {
    cpf = cpf.substring(0, 6) + "." + cpf.substring(6);
  }

  if (cpf.length > 3) {
    cpf = cpf.substring(0, 3) + "." + cpf.substring(3);
  }

  document.getElementById("cpf").value = cpf;
}

let ul = document.querySelector('nav .ul');

function openMenu() {
  ul.classList.add('open');
}

function closeMenu() {
  ul.classList.remove('open');
}

const chk = document.getElementById('chk')

chk.addEventListener('change', () => {
  document.body.classList.toggle('dark')
})